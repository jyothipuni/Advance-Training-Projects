package com.mphasis.intergararray;

public class Intergerarray 
{
	public static void main(String[] args) {  
        //Initialize array  
        int [] arr = new int [] {0,1,2,3,4,5,6};  
        int sum = 0,temp,avg = 0;  
        //Loop through the array to calculate sum of elements  
        for (int i = 0; i < arr.length; i++) {  
           sum = sum + arr[i];
           //average 
           avg=sum/arr.length;
           
           //smallest finding
           for(int j=i+1;j<arr.length;j++) {
        	   if(arr[i]>arr[j]) {
        		   temp=arr[i];
        		   arr[i]=arr[j];
        		   arr[j]=temp;
        		   
        	   }
        		   
        
           }
        }  
        System.out.println("Sum of all the elements of an array: " + sum);  
        System.out.println("Smallest element of the array: " + arr[0]); 
        System.out.println("Average number in the array :"+avg);
        
    }  
}  