package com.mphasis.rectangle;
import java.util.Scanner;
class Rectangle {
    int length; 
    int breadth; 
    int area; 
   
    public Rectangle()
    {
    	length = 0;
    	breadth= 0;
    }

    void input() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = in.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = in.nextInt();
    }

    void calculate() {
        area = length * breadth;
        
    }

    void display() {
        System.out.println("Area of Rectangle = " + area);
       
    }

    public static void main(String args[]) {
        Rectangle a1 = new Rectangle();
        a1.input();
        a1.calculate();
        a1.display();
        System.out.println("                                ");
        Rectangle a2 = new Rectangle();
        a2.input();
        a2.calculate();
        a2.display();
        System.out.println("                                ");
        Rectangle a3 = new Rectangle();
        a3.input();
        a3.calculate();
        a3.display();
        System.out.println("                                ");
        Rectangle a4 = new Rectangle();
        a4.input();
        a4.calculate();
        a4.display();
        System.out.println("                               ");
        Rectangle a5 = new Rectangle();
        a5.input();
        a5.calculate();
        a5.display();
    }
}
