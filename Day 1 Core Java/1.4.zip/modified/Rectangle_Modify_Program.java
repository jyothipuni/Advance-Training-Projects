package com.mphasis.modified;
import java.util.Scanner;

class Rectangle_Modify_Program {
    int length; 
    int width; 
    int area; 
    int parameter;
    
    public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	
    public Rectangle_Modify_Program()
    {
    	length = 1;
    	width= 1;
    }

    void input() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = in.nextInt();
        System.out.print("Enter width of rectangle: ");
        width = in.nextInt();
    }
    
    void  areaRectangle()
    {
        area = length * width;
       
    }
 
     void  perimeterRectangle()
    {
    	 parameter = 2*(length + width);
       
    }

    void display() {
    	if(length>0 && length<20)
        {
        System.out.println("Area of Rectangle = " + area);
        System.out.println("Parameter of Rectangle = " +parameter);}
       
        }

    public static void main(String args[]) {
    	
        Rectangle_Modify_Program a1 = new Rectangle_Modify_Program();
        a1.input();
        a1.areaRectangle();
        a1.perimeterRectangle();
        a1.display();
        System.out.println("                                   ");
        Rectangle_Modify_Program a2 = new Rectangle_Modify_Program();
        a2.input();
        a2.areaRectangle();
        a2.perimeterRectangle();
        a2.display();
        System.out.println("                                    ");
        Rectangle_Modify_Program a3 = new Rectangle_Modify_Program();
        a3.input();
        a3.areaRectangle();
        a3.perimeterRectangle();
        a3.display();
        System.out.println("                                     ");
        Rectangle_Modify_Program a4 = new Rectangle_Modify_Program();
        a4.input();
        a4.areaRectangle();
        a4.perimeterRectangle();
        a4.display();
        System.out.println("                                     ");
        Rectangle_Modify_Program a5 = new Rectangle_Modify_Program();
        a5.input();
        a5.areaRectangle();
        a5.perimeterRectangle();
        a5.display();
    	
    }
}
